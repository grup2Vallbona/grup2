import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';



import { AngularFireModule } from 'angularfire2';

// New imports to update based on AngularFire2 version 4
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';


import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { Login } from '../pages/login/login';
import { Register } from '../pages/register/register';
import { Principal } from '../pages/principal/principal';

import { Eventos } from '../pages/eventos/eventos';
import { Foro } from '../pages/foro/foro';
import { Valoraciones } from '../pages/valoraciones/valoraciones';
import { Novedades } from '../pages/novedades/novedades';

import { Movidas } from '../pages/movidas/movidas';
import { Usuario } from '../pages/usuario/usuario';
import { Asistentes } from '../pages/asistentes/asistentes';
import { Escuela } from '../pages/escuela/escuela';

import { Grupo } from '../pages/grupo/grupo';
import { Creargrupo } from '../pages/creargrupo/creargrupo';
import { Crearevento } from '../pages/crearevento/crearevento';




import { GruposService } from '../services/grupos.services';



  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDb6XSwvRwc09ZJlHyWtxKCmexYUDWKYGk",
    authDomain: "weswing-633a5.firebaseapp.com",
    databaseURL: "https://weswing-633a5.firebaseio.com",
    projectId: "weswing-633a5",
    storageBucket: "weswing-633a5.appspot.com",
    messagingSenderId: "567883692353"
  };




@NgModule({
  declarations: [
    MyApp,
    HomePage,
    Login,
    Register,
    Principal,
    Eventos,
    Foro,
    Valoraciones,
    Novedades,
    Movidas,
    Usuario,
    Asistentes,
    Escuela,
    Grupo,
    Creargrupo,
    Crearevento
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(config),
    AngularFireDatabaseModule,
    AngularFireAuthModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    Login,
    Register,
    Principal,
    Eventos,
    Foro,
    Valoraciones,
    Novedades,
    Movidas,
    Usuario,
    Asistentes,
    Escuela,
    Grupo,
    Creargrupo,
    Crearevento
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}, GruposService
  ]
})
export class AppModule {}
